
public class TestBase {
	
	public static WebDriver driver;
	public static Properties prop;
	public static EventFiringWebDriver e_driver;
	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;
	public static ExtentTest test;
	private static ITestContext testContext;
	private ITestResult result;
	//Excel Sheet related
	public static WriteToExcel excel;
	public static List<String> excelHeaderList = new ArrayList<String>(); 
	public static List<String> excelData  = new ArrayList<String>(); 
	public static String sheetName;
	
	public static String filePath = System.getProperty("user.dir");
	public TestBase()
	{
		try{
			prop = new Properties();			
			//FileInputStream ip = new FileInputStream(filePath+"\\config.properties");
			FileInputStream ip = new FileInputStream("./config.properties");
			prop.load(ip);
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void initialization(){
		String browserName = prop.getProperty("browser");
		
		if(browserName.equals("chrome"))
		{
			//System.setProperty("webdriver.chrome.driver", filePath+"\\drivers\\chromedriver.exe");
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();			
		}
		else if(browserName.equals("firefox"))
		{
			//System.setProperty("webdriver.gecko.driver", filePath+"\\drivers\\geckodriver.exe");
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		}
		else if(browserName.equals("edge"))
		{
			//System.setProperty("webdriver.edge.driver", filePath+"\\drivers\\msedgedriver.exe");
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		}
			
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get(prop.getProperty("url"));
		
	}
	
	public String getCurrentTime () {
    	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy_MM_dd_HH_mm_ss");  
	    LocalDateTime now = LocalDateTime.now();   
	    return dtf.format(now);
    }
	
	public String getCurrentDate () {
    	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd_MM_yyyy");  
	    LocalDateTime now = LocalDateTime.now();   
	    return dtf.format(now);
    }
	
	public String getCurrentMonthAndYear () {
		LocalDate currentdate = LocalDate.now();
		//Getting the current month
	    Month currentMonth = currentdate.getMonth();
	    
	    int currentYear = currentdate.getYear();
	    String currMon=currentMonth.toString();
	    return currentYear+"_"+currMon.substring(0,3);
    }
	
	
	@BeforeSuite
	public void beforeSuiteSetUp() {
		
		htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir")+"\\Test_Automaton_Report_"+getCurrentTime()+".html");
		//htmlReporter = new ExtentHtmlReporter(prop.getProperty("outputpath")+"\\Test_Automaton_Report_"+getCurrentTime()+".html");
		htmlReporter.config().setChartVisibilityOnOpen(true);
		htmlReporter.config().setDocumentTitle("Automation Test Report for "+prop.getProperty("excelFileName").replaceAll("_", " "));
		htmlReporter.config().setReportName("Test Report for "+prop.getProperty("excelFileName").replaceAll("_", " "));
		htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
		htmlReporter.config().setTheme(Theme.STANDARD);

		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		//extent.setSystemInfo("User name",System.getProperty("user.name"));
		extent.setSystemInfo("Time Zone", System.getProperty("user.timezone"));
		extent.setSystemInfo("User Location", System.getProperty("user.country"));
		extent.setSystemInfo("OS name", System.getProperty("os.name"));
		extent.setSystemInfo("OS version", System.getProperty("os.version"));
		extent.setSystemInfo("JDK version",System.getProperty("java.version"));
		
		//Code for the excel file generation
		excel = new WriteToExcel();	
		
		//Creating a new header if excelGenerationTime= mpnthly
		if(prop.getProperty("excelGenerationTime").equals("monthly"))
		{
			excelHeaderList.add("Execution Date");
			excelData.add(getCurrentDate());
		}
		
		excelHeaderList.add("Searched Keyword");
		excelHeaderList.add("SP Tech Found at ");
		excelHeaderList.add("Execution Start Time");
		excelHeaderList.add("Execution End Time");
		excelHeaderList.add("Total Execution Time");
		excelHeaderList.add("IP Address");
		excelHeaderList.add("City");
		excelHeaderList.add("State");
		excelHeaderList.add("Country");
		
		if(prop.getProperty("excelGenerationTime").equals("monthly"))
		{
			sheetName = getCurrentMonthAndYear();
		}else{
			sheetName = getCurrentDate();
		}
	}
	
	@AfterSuite
	public void tearDown() throws Exception {
		extent.flush();
		
		System.out.println("Excel Data SIze::"+excelData.size());
		excel.writeToExcel(excelHeaderList, excelData, prop.getProperty("excelFileName"), sheetName);
	}
	
	@AfterMethod
	public void getResult(ITestResult result) {
		//test=extent.createTest(result.getName());
		if (result.getStatus() == ITestResult.FAILURE) {
			test.log(Status.FAIL, MarkupHelper.createLabel(result.getName() + " Test case FAILED due to below issues:",	ExtentColor.RED));
			test.fail(result.getThrowable());
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			test.log(Status.PASS, MarkupHelper.createLabel(result.getName() + " Test Case PASSED", ExtentColor.GREEN));
		} else {
			test.log(Status.SKIP,
			MarkupHelper.createLabel(result.getName() + " Test Case SKIPPED", ExtentColor.ORANGE));
			test.skip(result.getThrowable());
		}
		TestUtil.closeBrowser(driver);
	}
	
	

	
	

}

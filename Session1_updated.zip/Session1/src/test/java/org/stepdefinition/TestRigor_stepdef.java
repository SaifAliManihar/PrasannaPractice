package org.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.github.bonigarcia.wdm.WebDriverManager;

public class TestRigor_stepdef {
	 WebDriver driver ;
	
	@Given("^Launch the chrome browser$")
    public void launch_url() throws Exception {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
//		WebDriverManager.edgedriver().setup();
//		driver = new EdgeDriver();
		
		// To MAximize the window size
		driver.manage().window().maximize();
    }
	
	@Then("^Launch testRigor URL$")
	public void lauch_testrigor_url() throws InterruptedException
	{
		// Launch a particular URL
		//driver.get("https://testrigor.com/");
		
		// Lauch a particular URL
		driver.navigate().to("https://testrigor.com/");
		Thread.sleep(5000);
	}
	
	@Then("^Validate the logo of testrigor$")
	public void validateLogo()
	{
		boolean logoAvailable = driver.findElement(By.xpath("(//img[contains(@src,'testRigor_logo')])[1]")).isDisplayed();
		if(logoAvailable==true)
		{
			System.out.println("Logo is available");
		}
		else
		{
			System.out.println("Logo is not available");
		}
	}
	
	@Then("^Click on Search icon$")
	public void click_on_search_icon() throws Exception
	{
		driver.findElement(By.xpath("//a[contains(@href,'/?s=')]")).click();
		Thread.sleep(3000);
	}
	
	@Then("^Verify Search textbox is visible or not$")
	public void verify_search_textbox() throws Exception
	{
		boolean searchAvailable = driver.findElement(By.xpath("//input[@id='wp-block-search__input-1']")).isDisplayed();
		if(searchAvailable==true)
		{
			driver.findElement(By.xpath("//input[@type='search']")).click();
			driver.findElement(By.xpath("//input[@type='search']")).sendKeys("Xray");
			Thread.sleep(1000);
			
			driver.findElement(By.xpath("//button[@type='submit']")).click();
		}
		else
		{
			System.out.println("Searchbox not displayed");
		}
	}
	
	
	

}
